# Released under the MIT License. See LICENSE for details.
#
"""Powerup related functionality."""

from __future__ import annotations

from typing import TYPE_CHECKING
from dataclasses import dataclass

if TYPE_CHECKING:
    from typing import Sequence, Tuple, Optional
    import ba


@dataclass
class PowerupMessage:
    """A message telling an object to accept a powerup.

    Category: Message Classes

    This message is normally received by touching a ba.PowerupBox.

    Attributes:

       poweruptype
          The type of powerup to be granted (a string).
          See ba.Powerup.poweruptype for available type values.

       sourcenode
          The node the powerup game from, or None otherwise.
          If a powerup is accepted, a ba.PowerupAcceptMessage should be sent
          back to the sourcenode to inform it of the fact. This will generally
          cause the powerup box to make a sound and disappear or whatnot.
    """
    poweruptype: str
    sourcenode: Optional[ba.Node] = None


@dataclass
class PowerupAcceptMessage:
    """A message informing a ba.Powerup that it was accepted.

    Category: Message Classes

    This is generally sent in response to a ba.PowerupMessage
    to inform the box (or whoever granted it) that it can go away.
    """


def get_default_powerup_distribution() -> Sequence[Tuple[str, int]]:
    """Standard set of powerups."""
    return (('triple_bombs', 3), ('ice_bombs', 3), ('punch', 3), ('champ',2), ('spunch',2), ('radius',2),('nap',2),('multibomb',2), ('blast',2),
            ('impact_bombs', 2), ('land_mines', 2), ('sticky_bombs', 3), ('slow',2), ('speed',2), ('inv',2), ('pwp',2), ('atomBomb',2),
            ('shield', 2), ('health', 2), ('iceImpact',2), ('curse', 1))
