# Released under the MIT License. See LICENSE for details.
#
"""
Provide top level UI related functionality.
"""
